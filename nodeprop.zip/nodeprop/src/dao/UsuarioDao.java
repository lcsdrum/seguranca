package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entidades.Usuario;
import util.ConnectionFactory;

public class UsuarioDao {

	private Connection connection;

	public UsuarioDao() {

		try {
			this.connection = new ConnectionFactory().getConnection();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void salvar(Usuario usuario) {
		String sql = "INSERT INTO usuario (nome, login, email, cpf, senha, confirmeSenha ) VALUES (?,?,?,?,?,?)";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);

			stmt.setString(1, usuario.getNome());
			stmt.setNString(2, usuario.getLogin());
			stmt.setString(3, usuario.getEmail());
			stmt.setString(4, usuario.getCpf());
			stmt.setString(5, usuario.getSenha());
			stmt.setString(6, usuario.getConfirmeSenha());
			
			stmt.execute();
			connection.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	

//		    private Usuario montarObjeto(ResultSet rs) throws SQLException {
//
//			Usuario usuario = new Usuario();
//			usuario.setNome(rs.getString("nome"));
//			usuario.setLogin(rs.getString("login"));
//			usuario.setEmail(rs.getString("email"));
//			usuario.setCpf(rs.getString("cpf"));
//			usuario.setSenha(rs.getString("senha"));
//			usuario.setConfirmeSenha(rs.getString("confirmeSenha"));
//			//usuario.setDataNascimento(rs.getDate("DataNascimento"));
//			
//			return usuario;
//		    }
 
		public boolean EfetuarLogin(String login, String senha){
			try{
				PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM usuario WHERE login = ? AND senha = ?");
				stmt.setString(1, login);
				stmt.setString(2, senha);
				
				ResultSet rs = stmt.executeQuery();
				if(rs.next()){
					return true;
				}
				rs.close();
				stmt.close();
				connection.close();
				return false;
			}catch (SQLException e){
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
}

