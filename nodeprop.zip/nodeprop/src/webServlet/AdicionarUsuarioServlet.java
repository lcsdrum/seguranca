package webServlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UsuarioDao;
import entidades.Usuario;

@WebServlet("/adicionarUsuario")
public class AdicionarUsuarioServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nome = request.getParameter("nome");
		String login = request.getParameter("login");
		String email = request.getParameter("email");
		String cpf = request.getParameter("cpf");
		String senha = request.getParameter("senha");
		String confirmeSenha = request.getParameter("confirmeSenha");
		

		Usuario usuario = new Usuario();
		usuario.setNome(nome);
		usuario.setLogin(login);
		usuario.setEmail(email);
		usuario.setCpf(cpf);
		usuario.setSenha(senha);
		usuario.setConfirmeSenha(confirmeSenha);

		UsuarioDao dao = new UsuarioDao();
		dao.salvar(usuario);

		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("Bem vindo!");
		out.println("<br />");
		out.println("<a href='index.jsp'>Página Inicial!</a>");
		out.println("</body>");
		out.println("</html>");
	}

}
