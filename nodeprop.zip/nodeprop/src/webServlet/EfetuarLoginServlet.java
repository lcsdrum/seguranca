package webServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UsuarioDao;
@WebServlet("/efetuarlogin")
public class EfetuarLoginServlet extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		
		UsuarioDao dao = new UsuarioDao();
		
		boolean var = dao.EfetuarLogin(login, senha);
		
		if(var == true) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<body>");
			out.println("Bem vindo!");
			out.println("<br />");
			out.println("<a href='index.jsp'>Página Inicial</a>");
			out.println("</body>");
			out.println("</html>");
			//request.getRequestDispatcher("index.jsp").forward(request, response);
		
		}else {
			
		if(var == false) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<body>");
			out.println("Conta não cadastrada!");
			out.println("<br />");
			out.println("<a href='cadastro.jsp'>Cadastre-se</a>");
			out.println("</body>");
			out.println("</html>");
		}
			
	}
	}}
