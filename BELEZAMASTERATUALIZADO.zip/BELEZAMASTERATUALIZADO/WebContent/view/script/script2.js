function teste(){
	alert ("teste");
}
